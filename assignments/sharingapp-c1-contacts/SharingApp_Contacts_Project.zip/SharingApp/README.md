# SharingApp Contacts

Open this SharingApp folder in Android Studio with JDK 17 or 21. Install Android SDK Platform 35 when prompted, let Gradle sync, and run app on an Android emulator or phone (Android 10/API 29 is suitable). Gradle wrapper 8.14.3 and Android Gradle plugin 8.7.3 are configured. The original support-library application is retained; no AndroidX conversion is necessary.

Implemented models: Contact.java and ContactList.java in app/src/main/java/com/example/sharingapp. Contact persistence uses app-private contacts.sav JSON. EditContactActivity validates before mutating and prevents edits/deletes of active borrowers. EditItemActivity validates borrower selection and applies status changes on Save.

Build: ./gradlew assembleDebug
The debug APK is generated at app/build/outputs/apk/debug/app-debug.apk.

An on-device walkthrough test is included in app/src/androidTest/java/com/example/sharingapp/ContactsWalkthroughTest.java. Run it against fresh app data; it deliberately adds sample contacts and an item. It requires an Android emulator/device and the Android test APK. Source changes are derived from the course starter project.
