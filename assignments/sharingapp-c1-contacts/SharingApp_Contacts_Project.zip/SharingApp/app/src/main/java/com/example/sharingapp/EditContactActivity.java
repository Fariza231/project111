package com.example.sharingapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

/** Edits or deletes a contact only when the contact is not an active borrower. */
public class EditContactActivity extends AppCompatActivity {
    private ContactList contact_list = new ContactList();
    private Contact contact;
    private EditText email;
    private EditText username;
    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_contact);
        context = getApplicationContext();
        contact_list.loadContacts(context);
        Intent intent = getIntent();
        int pos = intent.getIntExtra("position", -1);
        if (pos < 0 || pos >= contact_list.getSize()) { finish(); return; }
        contact = contact_list.getContact(pos);
        username = (EditText) findViewById(R.id.username);
        email = (EditText) findViewById(R.id.email);
        username.setText(contact.getUsername());
        email.setText(contact.getEmail());
        if (isActiveBorrower()) { refuseActiveBorrower(); }
    }

    private boolean isActiveBorrower() {
        ItemList items = new ItemList();
        items.loadItems(context);
        ContactList borrowers = new ContactList();
        borrowers.setContacts(items.getActiveBorrowers());
        return borrowers.hasContact(contact);
    }
    private void refuseActiveBorrower() {
        Toast.makeText(this, "Cannot edit or delete active borrower!", Toast.LENGTH_LONG).show();
        finish();
    }
    public void saveContact(View view) {
        if (contact == null) { return; }
        if (isActiveBorrower()) { refuseActiveBorrower(); return; }
        String username_str = username.getText().toString().trim();
        String email_str = email.getText().toString().trim();
        if (username_str.isEmpty()) { username.setError("Empty field!"); return; }
        if (email_str.isEmpty()) { email.setError("Empty field!"); return; }
        if (!email_str.contains("@")) { email.setError("Must be an email address!"); return; }
        Contact conflict = contact_list.getContactByUsername(username_str);
        if (conflict != null && !conflict.getId().equals(contact.getId())) {
            username.setError("Username already taken!"); return;
        }
        // Validate first. Keep the same identity without temporarily removing the contact.
        contact.setUsername(username_str);
        contact.setEmail(email_str);
        contact_list.saveContacts(context);
        finish();
    }
    public void deleteContact(View view) {
        if (contact == null) { return; }
        if (isActiveBorrower()) { refuseActiveBorrower(); return; }
        contact_list.deleteContact(contact);
        contact_list.saveContacts(context);
        finish();
    }
}
