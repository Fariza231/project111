package android.content;
public class Intent {public String destination;public Intent(Context c,Class<?> t){destination=t.getSimpleName();}public Intent(String action){}public Object resolveActivity(Object manager){return new Object();}public int getIntExtra(String key,int def){return def;}public android.os.Bundle getExtras(){return new android.os.Bundle();}}
