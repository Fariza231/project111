package androidx.appcompat.app;
public class AppCompatActivity extends android.content.Context {
 public static final int RESULT_OK=-1;
 protected void onCreate(android.os.Bundle b){}protected void onDestroy(){}protected void onActivityResult(int a,int b,android.content.Intent i){}
 public void setContentView(int id){}public android.view.View findViewById(int id){return null;}
 public android.content.Context getApplicationContext(){return this;}public Object getPackageManager(){return this;}
 public android.content.Intent getIntent(){return new android.content.Intent("test");}
 public void startActivity(android.content.Intent intent){com.example.sharingapp.Trace.add("navigate:"+intent.destination);}
 public void startActivityForResult(android.content.Intent intent,int code){}
 public void finish(){com.example.sharingapp.Trace.add("finish");}
}