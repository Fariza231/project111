package com.example.sharingapp;
public class Trace {public static java.util.ArrayList<String> events=new java.util.ArrayList<String>();public static boolean unique=true,success=true;public static void add(String e){events.add(e);}}
