package com.example.sharingapp;
import android.content.Context;import android.graphics.Bitmap;import java.util.ArrayList;
interface Observer {void update();}
class MainActivity extends androidx.appcompat.app.AppCompatActivity {}
class ItemList {}
class ContactList {public int getSize(){return 2;}}
class Contact {
 String username,email,id;
 Contact(String u,String e,String id){username=u;email=e;this.id=id==null?"generated-contact":id;Trace.add("contact:new:"+u+":"+e+":"+id);}
 public String getUsername(){Trace.add("contact:username:"+username);return username;}
}
class Item {
 String title,maker,description,id,length,width,height,status="Available";Contact borrower;Bitmap image;
 Item(String t,String m,String d,Bitmap image,String id){title=t;maker=m;description=d;this.image=image;this.id=id==null?"generated-item":id;Trace.add("item:new:"+t+":"+m+":"+d+":"+(image!=null)+":"+id);}
}
class ContactController {
 Contact contact;ContactController(Contact c){contact=c;}
 public String getId(){Trace.add("contact:id:"+contact.id);return contact.id;}
 public String getUsername(){return contact.username;}public String getEmail(){return contact.email;}
}
class ItemController {
 Item item;ItemController(Item i){item=i;}
 public String getId(){Trace.add("item:id:"+item.id);return item.id;}
 public void setDimensions(String l,String w,String h){item.length=l;item.width=w;item.height=h;Trace.add("dimensions:"+l+":"+w+":"+h);}
 public void setStatus(String status){item.status=status;Trace.add("status:"+status);}
 public void setBorrower(Contact c){item.borrower=c;Trace.add("borrower:"+(c==null?"null":c.username));}
 public Contact getBorrower(){return item.borrower;}public String getTitle(){return item.title;}public String getMaker(){return item.maker;}public String getDescription(){return item.description;}
 public String getLength(){return item.length;}public String getWidth(){return item.width;}public String getHeight(){return item.height;}public String getStatus(){return item.status;}public Bitmap getImage(){return item.image;}
}
class ItemListController {
 ItemListController(ItemList m){}public void loadItems(Context c){}public void addObserver(Observer o){}public void removeObserver(Observer o){Trace.add("unobserve:items");}
 public Item getItem(int p){return new Item("old","maker","description",null,"old-item-id");}
 public boolean addItem(Item i,Context c){Trace.add("add:item:"+i.id);return Trace.success;}
 public boolean editItem(Item old,Item i,Context c){Trace.add("edit:item:"+old.id+":"+i.id+":"+i.status+":"+(i.borrower==null?"null":i.borrower.username));return Trace.success;}
 public boolean deleteItem(Item i,Context c){Trace.add("delete:item:"+i.id);return Trace.success;}
}
class ContactListController {
 ContactListController(ContactList m){}public void loadContacts(Context c){}public void addObserver(Observer o){}public void removeObserver(Observer o){}
 public boolean isUsernameAvailable(String username){Trace.add("unique:"+username);return Trace.unique;}
 public Contact getContact(int p){return new Contact("alice","original@example.com","old-contact-id");}
 public ArrayList<String> getAllUsernames(){ArrayList<String> a=new ArrayList<String>();a.add("bob");return a;}
 public int getIndex(Contact c){return 0;}
 public Contact getContactByUsername(String u){Trace.add("lookup:"+u);return new Contact(u,"b@example.com","borrower-id");}
 public boolean addContact(Contact c,Context ctx){Trace.add("add:contact:"+c.id+":"+c.username+":"+c.email);return Trace.success;}
 public boolean editContact(Contact old,Contact c,Context ctx){Trace.add("edit:contact:"+old.id+":"+c.id+":"+c.username+":"+c.email);return Trace.success;}
 public boolean deleteContact(Contact c,Context ctx){Trace.add("delete:contact:"+c.id);return Trace.success;}
}
