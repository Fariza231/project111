package com.example.sharingapp;

import android.view.View;
import android.widget.*;
import java.lang.reflect.*;
import java.util.*;

/** Executes original and refactored save methods with the same widget/controller doubles. */
public class BehaviorCheck {
    static int passed;
    static class Input {
        Map<String,String> fields=new LinkedHashMap<String,String>();
        boolean success=true,unique=true,available=true,photo=false;
        Object selected="bob";
        String label;
        Input(String label){this.label=label;fields.put("title","Camera");fields.put("maker","Canon");fields.put("description","Camera description");fields.put("length","12");fields.put("width","8");fields.put("height","7");fields.put("username","alice");fields.put("email","a@b");}
        Input copy(String label){Input c=new Input(label);c.fields.putAll(fields);c.success=success;c.unique=unique;c.available=available;c.photo=photo;c.selected=selected;return c;}
    }
    static boolean assign(Object target,String name,Object value)throws Exception {
        try{Field field=target.getClass().getDeclaredField(name);field.setAccessible(true);field.set(target,value);return true;}
        catch(NoSuchFieldException absent){return false;}
    }
    static Object fixture(String className,Input input)throws Exception {
        Object target=Class.forName("com.example.sharingapp."+className).getDeclaredConstructor().newInstance();
        for(Map.Entry<String,String> field:input.fields.entrySet()) assign(target,field.getKey(),new EditText(field.getKey(),field.getValue()));
        assign(target,"context",new android.content.Context());
        assign(target,"status",new Switch(input.available));
        assign(target,"borrower_spinner",new Spinner(input.selected));
        assign(target,"image",input.photo?new android.graphics.Bitmap():null);
        Item old=new Item("original","maker","description",null,"old-item-id");
        assign(target,"item",old);assign(target,"item_controller",new ItemController(old));
        if(className.contains("EditContact")){
            Contact oldContact=new Contact("alice","old@example.com","old-contact-id");
            assign(target,"contact",oldContact);assign(target,"contact_controller",new ContactController(oldContact));
        }
        return target;
    }
    static List<String> invoke(Object target,Input input)throws Exception {
        Trace.events.clear();Trace.success=input.success;Trace.unique=input.unique;
        String method=target.getClass().getSimpleName().contains("Item")?"saveItem":"saveContact";
        try{target.getClass().getMethod(method,View.class).invoke(target,new View());}
        catch(InvocationTargetException error){Trace.add("throws:"+error.getCause().getClass().getName());}
        return new ArrayList<String>(Trace.events);
    }
    static void compare(String activity,Input input)throws Exception {
        List<String> before=invoke(fixture("Original"+activity,input),input);
        List<String> after=invoke(fixture(activity,input),input);
        if(!before.equals(after))throw new AssertionError(activity+" / "+input.label+"\nBEFORE "+before+"\nAFTER  "+after);
        passed++;
    }
    static void repeated(String activity)throws Exception {
        Input input=new Input("repeated invalid then valid");
        Object before=fixture("Original"+activity,input),after=fixture(activity,input);
        String key=activity.contains("Item")?"title":"email";
        List<String> original=new ArrayList<String>(),refactored=new ArrayList<String>();
        for(String value:new String[]{"",activity.contains("Item")?"Changed camera":"new@example.com",""}){
            Field a=before.getClass().getDeclaredField(key);a.setAccessible(true);((EditText)a.get(before)).value=value;
            Field b=after.getClass().getDeclaredField(key);b.setAccessible(true);((EditText)b.get(after)).value=value;
            original.addAll(invoke(before,input));refactored.addAll(invoke(after,input));
        }
        if(!original.equals(refactored))throw new AssertionError(activity+" repeated form reuse differs");
        passed++;
    }
    static void borrowerReset()throws Exception {
        Input input=new Input("borrower reset");input.available=false;
        Object before=fixture("OriginalEditItemActivity",input),after=fixture("EditItemActivity",input);
        if(!invoke(before,input).equals(invoke(after,input)))throw new AssertionError("First borrowed save differs");
        for(Object activity:new Object[]{before,after}){
            Field f=activity.getClass().getDeclaredField("status");f.setAccessible(true);((Switch)f.get(activity)).checked=true;
        }
        List<String> a=invoke(before,input),b=invoke(after,input);
        if(!a.equals(b) || !b.contains("edit:item:old-item-id:old-item-id:Available:null"))throw new AssertionError("Stale borrower reused: "+b);
        passed++;
    }
    public static void main(String[] args)throws Exception {
        String[] itemFields={"title","maker","description","length","width","height"};
        for(String activity:new String[]{"AddItemActivity","EditItemActivity"}){
            List<Input> variants=new ArrayList<Input>();variants.add(new Input("valid"));
            for(String field:itemFields){Input c=new Input("empty "+field);c.fields.put(field,"");variants.add(c);}
            Input all=new Input("all fields empty");for(String field:itemFields)all.fields.put(field,"");variants.add(all);
            Input spaces=new Input("whitespace retained");for(String field:itemFields)spaces.fields.put(field," ");variants.add(spaces);
            Input photo=new Input("attached photo retained");photo.photo=true;variants.add(photo);
            for(Input original:variants)for(boolean success:new boolean[]{true,false}){
                Input c=original.copy(original.label+" save="+success);c.success=success;compare(activity,c);
                if(activity.equals("EditItemActivity")){Input borrowed=c.copy(c.label+" borrowed");borrowed.available=false;compare(activity,borrowed);}
            }
        }
        for(boolean invalidTitle:new boolean[]{false,true}){
            Input c=new Input("existing null borrower-selection behavior");c.available=false;c.selected=null;if(invalidTitle)c.fields.put("title","");compare("EditItemActivity",c);
        }
        for(String activity:new String[]{"AddContactActivity","EditContactActivity"}){
            for(String username:new String[]{"alice","bob",""," "})for(String email:new String[]{"a@b","","bad"})
            for(boolean unique:new boolean[]{true,false})for(boolean success:new boolean[]{true,false}){
                Input c=new Input("username="+username+" email="+email+" unique="+unique+" save="+success);
                c.fields.put("username",username);c.fields.put("email",email);c.unique=unique;c.success=success;compare(activity,c);
            }
        }
        for(String activity:new String[]{"AddItemActivity","EditItemActivity","AddContactActivity","EditContactActivity"}){
            Method helper=Class.forName("com.example.sharingapp."+activity).getDeclaredMethod("validateInput");
            if(helper.getReturnType()!=boolean.class || !Modifier.isPrivate(helper.getModifiers()))throw new AssertionError("Wrong validateInput signature: "+activity);
            passed++;repeated(activity);
        }
        borrowerReset();
        System.out.println("RESULT: "+passed+" checks passed.");
        System.out.println("158 single-save trace comparisons + 5 repeated-save scenarios + 4 validateInput signature checks.");
        System.out.println("Compared field reads, error targets/messages/order, controller arguments, IDs, borrower/status handling, persistence-result branches, observer removal, navigation/finish and existing exception behavior.");
        System.out.println("Original and submitted Activity source executed on JVM with deterministic Android/widget/controller doubles; not an Android UI walkthrough.");
    }
}
