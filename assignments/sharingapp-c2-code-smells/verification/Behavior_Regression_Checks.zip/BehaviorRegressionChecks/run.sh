#!/usr/bin/env bash
set -euo pipefail
checks_dir="$(cd "$(dirname "$0")" && pwd)"
classes_dir="$(mktemp -d)"
trap 'rm -rf "$classes_dir"' EXIT
sources=()
while IFS= read -r source; do sources+=("$source"); done < <(find "$checks_dir/src" -name '*.java' -type f)
javac -d "$classes_dir" "${sources[@]}"
java -cp "$classes_dir" com.example.sharingapp.BehaviorCheck
