package com.example.sharingapp;

import android.graphics.Bitmap;

/** Validates and updates an item working model independently of UI widgets. */
public class ItemController {
    private final Item item;
    public ItemController(Item item) { this.item=item; }
    public Item getItem() { return item; }
    public void updateItem(String title,String maker,String description,String length,String width,String height,
                           Bitmap image,boolean available,Contact borrower) {
        String[] names={"title","maker","description","length","width","height"};
        String[] values={title,maker,description,length,width,height};
        for(int i=0;i<values.length;i++) {
            if(values[i]==null || values[i].trim().isEmpty()) {
                throw new ContactController.ValidationException(names[i],"Empty field!");
            }
        }
        if(!available && borrower==null) throw new ContactController.ValidationException("borrower","Select a borrower from contacts.");
        item.update(title.trim(),maker.trim(),description.trim(),new Dimensions(length.trim(),width.trim(),height.trim()),
                image,available?"Available":"Borrowed",available?null:borrower);
    }
}
