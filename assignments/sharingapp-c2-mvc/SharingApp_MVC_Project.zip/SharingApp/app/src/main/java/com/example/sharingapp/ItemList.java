package com.example.sharingapp;

import android.content.Context;
import com.google.gson.Gson;
import com.google.gson.JsonParseException;
import com.google.gson.reflect.TypeToken;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.lang.reflect.Type;
import java.util.ArrayList;

/** Observable item collection; persistence remains compatible with the supplied commands. */
public class ItemList implements Item.Observer {
    public interface Observer { void onItemsChanged(ItemList items); }
    private ArrayList<Item> items = new ArrayList<Item>();
    private String FILENAME = "items.sav";
    private transient ArrayList<Observer> observers;

    public ItemList() { }
    public void setItems(ArrayList<Item> values) {
        for (Item item : items) { item.removeObserver(this); }
        items = new ArrayList<Item>();
        if (values != null) {
            for (Item item : values) {
                if (item != null) { items.add(item); item.addObserver(this); }
            }
        }
        notifyObservers();
    }
    public ArrayList<Item> getItems() { return new ArrayList<Item>(items); }
    public void addItem(Item item) {
        if (item == null) { throw new IllegalArgumentException("Item is required"); }
        if (hasItem(item)) { throw new IllegalArgumentException("Item ID already exists"); }
        items.add(item); item.addObserver(this); notifyObservers();
    }
    public void deleteItem(Item item) {
        int index = getIndex(item);
        if (index >= 0) { items.remove(index).removeObserver(this); notifyObservers(); }
    }
    public Item getItem(int index) { return items.get(index); }
    public int getSize() { return items.size(); }
    public int getIndex(Item item) {
        if (item == null || item.getId() == null) { return -1; }
        for (int i = 0; i < items.size(); i++) {
            if (item.getId().equals(items.get(i).getId())) { return i; }
        }
        return -1;
    }
    public boolean hasItem(Item item) { return getIndex(item) >= 0; }
    public ArrayList<Item> filterItemsByStatus(String status) {
        ArrayList<Item> result = new ArrayList<Item>();
        for (Item item : items) { if (status.equals(item.getStatus())) { result.add(item); } }
        return result;
    }
    public ArrayList<Contact> getActiveBorrowers() {
        ArrayList<Contact> result = new ArrayList<Contact>();
        for (Item item : items) {
            if ("Borrowed".equals(item.getStatus()) && item.getBorrower() != null) { result.add(item.getBorrower()); }
        }
        return result;
    }
    public void loadItems(Context context) {
        try (InputStreamReader reader = new InputStreamReader(context.openFileInput(FILENAME), "UTF-8")) {
            Type type = new TypeToken<ArrayList<Item>>() {}.getType();
            ArrayList<Item> loaded = new Gson().fromJson(reader, type);
            setItems(loaded);
        } catch (IOException | JsonParseException error) {
            setItems(new ArrayList<Item>());
        }
    }
    /** Write a temporary file first so a failed save does not truncate the committed file. */
    public boolean saveItems(Context context) {
        File temporary = context.getFileStreamPath(FILENAME + ".tmp");
        try {
            try (OutputStreamWriter writer = new OutputStreamWriter(
                    context.openFileOutput(FILENAME + ".tmp", Context.MODE_PRIVATE), "UTF-8")) {
                new Gson().toJson(items, writer);
            }
            return temporary.renameTo(context.getFileStreamPath(FILENAME));
        } catch (IOException error) { return false; }
        finally { if (temporary.exists()) { temporary.delete(); } }
    }
    public void addObserver(Observer observer) {
        if (observers == null) { observers = new ArrayList<Observer>(); }
        if (observer != null && !observers.contains(observer)) { observers.add(observer); }
    }
    public void removeObserver(Observer observer) {
        if (observers != null) { observers.remove(observer); }
    }
    public void notifyObservers() {
        if (observers != null) {
            for (Observer observer : new ArrayList<Observer>(observers)) { observer.onItemsChanged(this); }
        }
    }
    @Override public void onItemChanged(Item item) { notifyObservers(); }
}
