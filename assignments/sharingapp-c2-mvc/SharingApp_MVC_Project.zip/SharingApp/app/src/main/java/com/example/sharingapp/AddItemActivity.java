package com.example.sharingapp;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.provider.MediaStore;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

/**
 * Add a new item
 */
public class AddItemActivity extends AppCompatActivity implements Item.Observer {

    private EditText title;
    private EditText maker;
    private EditText description;
    private EditText length;
    private EditText width;
    private EditText height;

    private ImageView photo;
    private Bitmap image;
    private int REQUEST_CODE = 1;

    private ItemListController item_list_controller;
    private ItemController item_controller;
    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        title = (EditText) findViewById(R.id.title);
        maker = (EditText) findViewById(R.id.maker);
        description = (EditText) findViewById(R.id.description);
        length = (EditText) findViewById(R.id.length);
        width = (EditText) findViewById(R.id.width);
        height = (EditText) findViewById(R.id.height);
        photo = (ImageView) findViewById(R.id.image_view);

        photo.setImageResource(android.R.drawable.ic_menu_gallery);

        context = getApplicationContext();
        item_list_controller = new ItemListController(context);
        item_list_controller.loadItems();
        item_controller = new ItemController(new Item("", "", "", new Dimensions("", "", ""), null, null));
    }

    public void saveItem(View view) {
        try {
            item_controller.updateItem(title.getText().toString(), maker.getText().toString(), description.getText().toString(), length.getText().toString(), width.getText().toString(), height.getText().toString(), image, true, null);
            if (item_list_controller.addItem(item_controller.getItem())) { navigateHome(); }
            else { android.widget.Toast.makeText(this, "Unable to save item.", android.widget.Toast.LENGTH_LONG).show(); }
        } catch (ContactController.ValidationException error) {
            int id = getResources().getIdentifier(error.getField(), "id", getPackageName());
            View field = id == 0 ? null : findViewById(id);
            if (field instanceof EditText) { ((EditText) field).setError(error.getMessage()); }
            else { android.widget.Toast.makeText(this, error.getMessage(), android.widget.Toast.LENGTH_LONG).show(); }
        }
    }

    public void addPhoto(View view) {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(intent, REQUEST_CODE);
        }
    }

    public void deletePhoto(View view) {
        image = null;
        photo.setImageResource(android.R.drawable.ic_menu_gallery);
    }

    @Override
    protected void onActivityResult(int request_code, int result_code, Intent intent) {
        super.onActivityResult(request_code, result_code, intent);
        if (request_code == REQUEST_CODE && result_code == RESULT_OK && intent != null && intent.getExtras() != null) {
            Bundle extras = intent.getExtras();
            image = (Bitmap) extras.get("data");
            photo.setImageBitmap(image);
        }
    }

    private void navigateHome() {
        startActivity(new Intent(this, MainActivity.class)); finish();
    }
    @Override protected void onStart() {
        super.onStart();
        if (item_controller != null) { item_controller.getItem().addObserver(this); }
    }
    @Override protected void onStop() {
        if (item_controller != null) { item_controller.getItem().removeObserver(this); }
        super.onStop();
    }
    @Override public void onItemChanged(final Item updated) {
        runOnUiThread(new Runnable() { @Override public void run() {
            title.setText(updated.getTitle()); maker.setText(updated.getMaker()); description.setText(updated.getDescription());
            length.setText(updated.getDimensions().getLength()); width.setText(updated.getDimensions().getWidth());
            height.setText(updated.getDimensions().getHeight());
            image = updated.getImage();
            if (image != null) { photo.setImageBitmap(image); }
            else { photo.setImageResource(android.R.drawable.ic_menu_gallery); }
        }});
    }
}
