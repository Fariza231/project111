package com.example.sharingapp;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.UUID;

/** Observable item domain model; image bytes are persisted, UI observers are not. */
public class Item {
    public interface Observer { void onItemChanged(Item item); }
    private String title;
    private String maker;
    private String description;
    private Dimensions dimensions;
    private String status;
    private Contact borrower;
    protected transient Bitmap image;
    protected String image_base64;
    private String id;
    private transient ArrayList<Observer> observers;
    public Item(String title, String maker, String description, Dimensions dimensions, Bitmap image, String id) {
        this.title=title; this.maker=maker; this.description=description; this.dimensions=dimensions;
        this.status="Available"; this.id=id==null?UUID.randomUUID().toString():id; encodeImage(image);
    }
    public String getId() { return id; }
    public void setId() { updateId(UUID.randomUUID().toString()); }
    public void updateId(String id) { this.id=id; notifyObservers(); }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title=title; notifyObservers(); }
    public String getMaker() { return maker; }
    public void setMaker(String maker) { this.maker=maker; notifyObservers(); }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description=description; notifyObservers(); }
    public Dimensions getDimensions() { return dimensions; }
    public void setDimensions(Dimensions dimensions) { this.dimensions=dimensions; notifyObservers(); }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status=status; notifyObservers(); }
    public Contact getBorrower() { return borrower; }
    public void setBorrower(Contact borrower) { this.borrower=borrower; notifyObservers(); }
    private void encodeImage(Bitmap value) {
        image=value; image_base64=null;
        if (value!=null) {
            ByteArrayOutputStream stream=new ByteArrayOutputStream();
            value.compress(Bitmap.CompressFormat.PNG,100,stream);
            image_base64=Base64.encodeToString(stream.toByteArray(),Base64.DEFAULT);
        }
    }
    public void addImage(Bitmap value) { encodeImage(value); notifyObservers(); }
    public Bitmap getImage() {
        if(image==null && image_base64!=null) {
            byte[] bytes=Base64.decode(image_base64,Base64.DEFAULT);
            image=BitmapFactory.decodeByteArray(bytes,0,bytes.length);
        }
        return image;
    }
    public void update(String title,String maker,String description,Dimensions dimensions,Bitmap image,String status,Contact borrower) {
        this.title=title;this.maker=maker;this.description=description;this.dimensions=dimensions;
        this.status=status;this.borrower=borrower;encodeImage(image);notifyObservers();
    }
    public void addObserver(Observer observer) {
        if(observers==null) observers=new ArrayList<Observer>();
        if(observer!=null && !observers.contains(observer)) observers.add(observer);
    }
    public void removeObserver(Observer observer) { if(observers!=null) observers.remove(observer); }
    public void notifyObservers() {
        if(observers!=null) for(Observer observer:new ArrayList<Observer>(observers)) observer.onItemChanged(this);
    }
}
