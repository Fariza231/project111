package com.example.sharingapp;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

/** List view observing its model and delegating eligibility queries to the controller. */
public class ContactsActivity extends AppCompatActivity implements ContactList.Observer {
    private ContactListController controller;
    private ArrayAdapter<Contact> adapter;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);setContentView(R.layout.activity_contacts);
        controller=new ContactListController(getApplicationContext());
        ListView list=(ListView)findViewById(R.id.my_contacts);
        adapter=new ContactAdapter(this,controller.getContactList().getContacts());list.setAdapter(adapter);
        list.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override public boolean onItemLongClick(AdapterView<?> parent,View view,int position,long id) {
                Contact contact=adapter.getItem(position);
                if(controller.isActiveBorrower(contact)) {
                    Toast.makeText(ContactsActivity.this,"Cannot edit or delete active borrower!",Toast.LENGTH_LONG).show();return true;
                }
                int index=controller.getContactList().getIndex(contact);
                if(index>=0) {
                    Intent edit=new Intent(ContactsActivity.this,EditContactActivity.class);
                    edit.putExtra("position",index);startActivity(edit);
                }
                return true;
            }
        });
    }
    @Override protected void onStart() {
        super.onStart();controller.getContactList().addObserver(this);controller.loadContacts();
    }
    @Override protected void onStop() {
        controller.getContactList().removeObserver(this);super.onStop();
    }
    @Override public void onContactsChanged(final ContactList model) {
        runOnUiThread(new Runnable(){@Override public void run(){
            adapter.clear();adapter.addAll(model.getContacts());adapter.notifyDataSetChanged();
        }});
    }
    public void addContactActivity(View view) {startActivity(new Intent(this,AddContactActivity.class));}
}
