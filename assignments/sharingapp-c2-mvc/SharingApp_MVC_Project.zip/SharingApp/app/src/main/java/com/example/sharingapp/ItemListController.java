package com.example.sharingapp;

import android.content.Context;
import java.util.ArrayList;

/** Coordinates item commands and restores memory if persistence fails. */
public class ItemListController {
    private final ItemList model;
    private final Context context;
    public ItemListController(ItemList model,Context context) { this.model=model;this.context=context; }
    public ItemListController(Context context) { this(new ItemList(),context); }
    public ItemList getItemList() { return model; }
    public void loadItems() { model.loadItems(context); }
    public ArrayList<Item> getItems() { return model.getItems(); }
    public ArrayList<Item> filterItemsByStatus(String status) { return model.filterItemsByStatus(status); }
    public int getIndex(Item item) { return model.getIndex(item); }
    public Item getItem(int index) { return model.getItem(index); }
    public int getSize() { return model.getSize(); }
    private boolean execute(Command command) {
        ArrayList<Item> before=model.getItems();
        try { command.execute(); if(command.isExecuted()) return true; }
        catch(RuntimeException error) { model.setItems(before);throw error; }
        model.setItems(before);return false;
    }
    public boolean addItem(Item item) { return execute(new AddItemCommand(model,item,context)); }
    public boolean editItem(Item oldItem,Item replacement) {
        int index=model.getIndex(oldItem);
        if(index<0 || !oldItem.getId().equals(replacement.getId())) throw new IllegalArgumentException("Retain an existing item ID");
        return execute(new EditItemCommand(model,model.getItem(index),replacement,context));
    }
    public boolean deleteItem(Item item) {
        int index=model.getIndex(item);
        return index>=0 && execute(new DeleteItemCommand(model,model.getItem(index),context));
    }
}
