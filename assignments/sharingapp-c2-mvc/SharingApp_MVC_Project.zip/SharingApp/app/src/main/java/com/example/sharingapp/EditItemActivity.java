package com.example.sharingapp;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.provider.MediaStore;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

/**
 * Editing a pre-existing item consists of deleting the old item and adding a new item with the old
 * item's id.
 * Note: invisible EditText is used to setError for status. For whatever reason we cannot .setError to
 * the status Switch so instead an error is set to an "invisible" EditText.
 */
public class EditItemActivity extends AppCompatActivity implements Item.Observer {

    private ItemListController item_list_controller;
    private ItemController item_controller;
    private Item item;
    private Context context;

    private ContactListController contact_list_controller;

    private Bitmap image;
    private int REQUEST_CODE = 1;
    private ImageView photo;

    private EditText title;
    private EditText maker;
    private EditText description;
    private EditText length;
    private EditText width;
    private EditText height;
    private Spinner borrower_spinner;
    private TextView  borrower_tv;
    private Switch status;
    private EditText invisible;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_item);

        title = (EditText) findViewById(R.id.title);
        maker = (EditText) findViewById(R.id.maker);
        description = (EditText) findViewById(R.id.description);
        length = (EditText) findViewById(R.id.length);
        width = (EditText) findViewById(R.id.width);
        height = (EditText) findViewById(R.id.height);
        borrower_spinner = (Spinner) findViewById(R.id.borrower_spinner);
        borrower_tv = (TextView) findViewById(R.id.borrower_tv);
        photo = (ImageView) findViewById(R.id.image_view);
        status = (Switch) findViewById(R.id.available_switch);
        invisible = (EditText) findViewById(R.id.invisible);

        invisible.setVisibility(View.GONE);

        context = getApplicationContext();
        item_list_controller = new ItemListController(context);
        item_list_controller.loadItems();
        contact_list_controller = new ContactListController(context);
        contact_list_controller.loadContacts();

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item, contact_list_controller.getAllUsernames());
        borrower_spinner.setAdapter(adapter);

        Intent intent = getIntent();   // Get intent from ItemsFragment
        int pos = intent.getIntExtra("position", 0);

        if (pos < 0 || pos >= item_list_controller.getSize()) { finish(); return; }
        item = item_list_controller.getItem(pos);
        Dimensions original_dimensions = item.getDimensions();
        Item working = new Item(item.getTitle(), item.getMaker(), item.getDescription(),
                new Dimensions(original_dimensions.getLength(), original_dimensions.getWidth(), original_dimensions.getHeight()),
                item.getImage(), item.getId());
        working.setStatus(item.getStatus()); working.setBorrower(item.getBorrower());
        item_controller = new ItemController(working);

        Contact contact = item.getBorrower();
        if (contact != null){
            int contact_pos = contact_list_controller.getContactList().getIndex(contact);
            if (contact_pos >= 0) { borrower_spinner.setSelection(contact_pos); }
        }

        title.setText(item.getTitle());
        maker.setText(item.getMaker());
        description.setText(item.getDescription());

        Dimensions dimensions = item.getDimensions();

        length.setText(dimensions.getLength());
        width.setText(dimensions.getWidth());
        height.setText(dimensions.getHeight());

        String status_str = item.getStatus();
        if (status_str.equals("Borrowed")) {
            status.setChecked(false);
        } else {
            borrower_tv.setVisibility(View.GONE);
            borrower_spinner.setVisibility(View.GONE);
        }

        image = item.getImage();
        if (image != null) {
            photo.setImageBitmap(image);
        } else {
            photo.setImageResource(android.R.drawable.ic_menu_gallery);
        }
    }

    public void addPhoto(View view) {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(intent, REQUEST_CODE);
        }
    }

    public void deletePhoto(View view) {
        image = null;
        photo.setImageResource(android.R.drawable.ic_menu_gallery);
    }

    @Override
    protected void onActivityResult(int request_code, int result_code, Intent intent) {
        super.onActivityResult(request_code, result_code, intent);
        if (request_code == REQUEST_CODE && result_code == RESULT_OK && intent != null && intent.getExtras() != null) {
            Bundle extras = intent.getExtras();
            image = (Bitmap) extras.get("data");
            photo.setImageBitmap(image);
        }
    }

    public void deleteItem(View view) {
        if (item_list_controller.deleteItem(item)) { navigateHome(); }
        else { android.widget.Toast.makeText(this, "Unable to save item.", android.widget.Toast.LENGTH_LONG).show(); }
    }

    public void saveItem(View view) {
        try {
            Object selected = borrower_spinner.getSelectedItem();
            Contact borrower = selected == null ? null : contact_list_controller.getContactByUsername(selected.toString());
            item_controller.updateItem(title.getText().toString(), maker.getText().toString(), description.getText().toString(), length.getText().toString(), width.getText().toString(), height.getText().toString(), image, status.isChecked(), borrower);
            if (item_list_controller.editItem(item, item_controller.getItem())) { navigateHome(); }
            else { android.widget.Toast.makeText(this, "Unable to save item.", android.widget.Toast.LENGTH_LONG).show(); }
        } catch (ContactController.ValidationException error) {
            int id = getResources().getIdentifier(error.getField(), "id", getPackageName());
            View field = id == 0 ? null : findViewById(id);
            if (field instanceof EditText) { ((EditText) field).setError(error.getMessage()); }
            else { android.widget.Toast.makeText(this, error.getMessage(), android.widget.Toast.LENGTH_LONG).show(); }
        }
    }

    /**
     * Checked = Available
     * Unchecked = Borrowed
     */
    public void toggleSwitch(View view) {
        if (!status.isChecked()) {
            try { contact_list_controller.requireBorrowerOptions(); }
            catch (ContactController.ValidationException error) {
                status.setChecked(true);
                android.widget.Toast.makeText(this, error.getMessage(), android.widget.Toast.LENGTH_LONG).show();
            }
        }
        int visibility = status.isChecked() ? View.GONE : View.VISIBLE;
        borrower_spinner.setVisibility(visibility); borrower_tv.setVisibility(visibility);
    }

    private void navigateHome() {
        startActivity(new Intent(this, MainActivity.class)); finish();
    }
    @Override protected void onStart() {
        super.onStart();
        if (item_controller != null) { item_controller.getItem().addObserver(this); }
    }
    @Override protected void onStop() {
        if (item_controller != null) { item_controller.getItem().removeObserver(this); }
        super.onStop();
    }
    @Override public void onItemChanged(final Item updated) {
        runOnUiThread(new Runnable() { @Override public void run() {
            title.setText(updated.getTitle()); maker.setText(updated.getMaker()); description.setText(updated.getDescription());
            length.setText(updated.getDimensions().getLength()); width.setText(updated.getDimensions().getWidth());
            height.setText(updated.getDimensions().getHeight());
            image = updated.getImage();
            if (image != null) { photo.setImageBitmap(image); }
            else { photo.setImageResource(android.R.drawable.ic_menu_gallery); }
        }});
    }
}
